package demo;

public class TestCase {
	@Test
	public void testAbc(){
		System.out.println("Abc");
	}
	
	@Test
	public void testHello(){
		System.out.println("Hello World!");
	}
}

package cn.tedu.demo;

public class Son  extends Parent{

	public Son test(int a,String b){
		return new Son();
	}
}

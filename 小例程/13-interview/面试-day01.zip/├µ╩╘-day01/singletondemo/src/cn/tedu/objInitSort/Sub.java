package cn.tedu.objInitSort;

public class Sub extends Super {
	int a = 8;
	
	public Sub(){
		test();
	}
	
	public void test(){
		System.out.println(a);
	}
}

package cn.tedu.objInitSort;

public class Test {
	public static void main(String[] args) {
//		Super su = new Sub();
//		System.out.println(su.a);
//		su.test();
		new Sub();
	}

}

package cn.tedu.objInitSort;

public class Super {
	int a = 6;
	
	public Super(){
		test();
	}
	
	public void test(){
		System.out.println(a);
	}

}

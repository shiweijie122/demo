package cn.tedu.demo;

public class Parent {
	
	public Parent test(int a,String b){
		return new Parent();
	}

}

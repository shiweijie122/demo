$(document).ready(function(){
	//1.在保存按钮上注册事件,事件执行时调用doSaveOrUpdate
})
function doSaveOrUpdate(){
	//1.获得输入的数据
	//2.将数据异步发送到服务端
}
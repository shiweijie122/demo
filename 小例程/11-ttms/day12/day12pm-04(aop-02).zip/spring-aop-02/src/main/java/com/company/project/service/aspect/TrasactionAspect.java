package com.company.project.service.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

/**
 * @Component 通过此注解告诉spring容器,这个对象\
 * 要由spring来管理.
 * @Aspect 通过此注解声明这是一个切面
 * */
@Aspect
@Component
public class TrasactionAspect {
	@Before("bean(projectServiceImpl)")
	public void beginTx(){
		System.out.println("开启事务");
	}
	@After("bean(projectServiceImpl)")
	public void commitTx(){
		System.out.println("提交事务");
	}
}

package com.company.project.service;

public interface ProjectService {

	 void saveObject(Object obj);
	 void updateObject(Object obj);
	 
}

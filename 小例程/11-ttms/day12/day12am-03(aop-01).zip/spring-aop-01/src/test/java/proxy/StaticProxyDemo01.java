package proxy;

import com.company.project.service.ProjectService;
import com.company.project.service.impl.ProjectServiceImpl;
import com.company.project.service.impl.ProjectServiceProxy;

public class StaticProxyDemo01 {
	public static void main(String[] args) {
		//具体业务对象(负责执行核心业务)
		ProjectServiceImpl psImpl=
			new  ProjectServiceImpl();
		//构建扩展业务对象
		ProjectService ps=
		new ProjectServiceProxy(psImpl);
		ps.saveProject();
		ps.updateProject();
		
	}
}

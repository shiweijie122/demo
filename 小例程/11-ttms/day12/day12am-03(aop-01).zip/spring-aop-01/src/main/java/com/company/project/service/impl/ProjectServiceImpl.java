package com.company.project.service.impl;
import com.company.project.service.ProjectService;
//OCP原则(开闭原则:对扩展开放,对修改关闭)
public class ProjectServiceImpl implements ProjectService {
	public void saveProject() {
		//long start=System.nanoTime();
	    System.out.println("save.project");
	    //long end=System.nanoTime();
	    //System.out.println("run.time="+(end-start));
	}
	public void updateProject() {
		//long start=System.nanoTime();
		System.out.println("update.project");
		//long end=System.nanoTime();
		//System.out.println("run.time="+(end-start));
	}
}
package com.company.project.service.impl;
import com.company.project.service.ProjectService;

//Spring的AOP可以自动为业务对象创建这样的一个代理对象
//然后为目标对象添加扩展功能.
public class ProjectServiceProxy implements ProjectService {
	private ProjectService projectService;
	
	public ProjectServiceProxy(ProjectService projectService){
		this.projectService=projectService;
	}
	
	public void saveProject() {
		long start=System.nanoTime();
		projectService.saveProject();
		long end=System.nanoTime();
		System.out.println("run.time="+(end-start));
	}
	public void updateProject() {
		long start=System.nanoTime();
		projectService.updateProject();
		long end=System.nanoTime();
		System.out.println("run.time="+(end-start));
	}
}

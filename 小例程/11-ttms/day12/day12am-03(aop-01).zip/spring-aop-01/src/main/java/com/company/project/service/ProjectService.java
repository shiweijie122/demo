package com.company.project.service;

public interface ProjectService {

	void saveProject();
	void updateProject();
	//......
}

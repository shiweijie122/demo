//$(function(){})
$(document).ready(function(){
//1.在模态框的保存按钮上注册事件,
	//事件执行时调用doSaveOrUpdate
	$("#modal-dialog")
	.on("click",".ok",doSaveOrUpdate);
});
/* 点击模态框上的save按钮时执行此函数,
 * 通过此函数发送异步请求将页面上的数据
 * 发送到服务端.
 */
function doSaveOrUpdate(){
	//1.获得输入的数据
	var params=getEditFormData();
	//2.将数据异步发送到服务端
	//2.1定义url(对应controller中的一个方法)
	var url="project/doSaveObject.do"
	//2.2发送异步请求	
	$.post(url,params,function(result){
		console.log(JSON.stringify(result));
		if(result.state==1){
		 //隐藏模态框
		 $("#modal-dialog").modal("hide");
		 //重新查询(调用的project_list.js中的doGetObjects)
		 doGetObjects();
		}else{
		 alert(result.message);
		}
	});//doSaveObject(Project entity)
}
function getEditFormData(){
 //1.获得页面上用户输入的数据,封装为json对象(相对比较灵活)
  var params={//根据id获得数据
	  "name":$("#nameId").val(),
	  "code":$("#codeId").val(),
	  "beginDate":$("#beginDateId").val(),
	  "endDate":$("#endDateId").val(),
	  "valid":$('input[name="valid"]:checked').val(),
	  "note":$("#noteId").val()
  }
  console.log(JSON.stringify(params));
  //2.返回json对象
  return params;
}





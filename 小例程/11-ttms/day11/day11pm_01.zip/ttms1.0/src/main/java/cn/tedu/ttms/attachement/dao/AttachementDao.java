package cn.tedu.ttms.attachement.dao;

import cn.tedu.ttms.attachement.entity.Attchement;

public interface AttachementDao {
	int insertObject(Attchement entity);
}

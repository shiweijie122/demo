package cn.tedu.ttms.attachment.service.impl;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import cn.tedu.ttms.attachment.service.AttachementService;
import cn.tedu.ttms.common.exception.ServiceException;
@Service
public class AttachementServiceImpl implements AttachementService {

	@Override
	public void uploadObject(String title,
			MultipartFile mFile) {
		//1.实现文件上传
		//1.1验证参数有效性
		if(title==null)
		throw new ServiceException("上传标题不能为空");
		if(mFile==null)
		throw new ServiceException("需要选择上传文件");
		if(mFile.isEmpty())
		throw new ServiceException("上传文件不能为空");
		//1.2判定文件是否已经上传过?
		//1.3实现文件上传
		//1.3.1 构建文件上传路径(d:/uploads/2017/08/15/xxxxx.png)
		SimpleDateFormat sdf=
		new SimpleDateFormat("yyyy/MM/dd");
		String dateDir=sdf.format(new Date());
		String baseDir="d:/uploads/";
		File uploadDir=new File(baseDir+dateDir);
		if(!uploadDir.exists()){
			uploadDir.mkdirs();
		}
		//1.3.2 构建新的文件名
		String srcFileName=
		mFile.getOriginalFilename();
		String destfileName=
		UUID.randomUUID().toString()+"."
		+FilenameUtils.getExtension(srcFileName);
		
		//1.3.3创建目标文件对象
		File dest=new File(uploadDir,
				destfileName);
		//1.3.4 实现文件上传
	    try{
		mFile.transferTo(dest);
	    }catch(IOException e){
	    e.printStackTrace();
	    throw new ServiceException("文件上传失败");
	    }
		//2.将文件相关信息写入数据库
	}

}

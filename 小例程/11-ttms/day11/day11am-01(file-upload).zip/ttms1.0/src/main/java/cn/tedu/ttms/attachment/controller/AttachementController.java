package cn.tedu.ttms.attachment.controller;

import java.io.File;
import java.io.IOException;

import javax.annotation.Resource;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.tedu.ttms.attachment.service.AttachementService;
import cn.tedu.ttms.common.web.JsonResult;

@Controller
@RequestMapping("/attachement/")
public class AttachementController {
	@Resource
	private AttachementService attachementService;
    @RequestMapping("attachementUI")
	public String attachmentUI(){
		return "attachement/attachement";
	}
    /**
     * @param title 为附件标题
     * @param mFile 用于接收上传的附件的对象
     * */
    @RequestMapping("doUpload")
    @ResponseBody
    public JsonResult doUpload(
    		String title,
    		MultipartFile mFile){
    	attachementService
    	.uploadObject(title, mFile);
    	return new JsonResult();
    }
}

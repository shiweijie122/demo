package cn.tedu.ttms.product.service;

import java.util.List;
import java.util.Map;

public interface TeamService {
     /**根据条件查询当前页数据*/
	 Map<String,Object>findObjects(
			   Integer valid,
			   Integer projectId,
			   Integer pageCurrent);
	 /**查询项目id和名称信息*/
	 List<Map<String,Object>>
	           findPrjIdAndNames();
}

//页面加载完成执行
$(document).ready(function(){
	//初始化所属项目的select列表
	doGetProjectIdAndNames();
	//在模态框的对应按钮上注册事件
	$("#modal-dialog")
	.on("click",".ok",doSaveObject);
	//在模态框隐藏时解除事件的注册
	$("#modal-dialog")
	//hidden.bs.modal为固定写法表示模态框隐藏事件
	.on("hidden.bs.modal",function(){
		//.ok上移除click事件
		$(this).off("click",".ok");
	});
});
function doSaveObject(){
	//1.验证表单数据(非空验证)
	if(!$("#editFormId").valid())return;
	//2.获得表单数据
	var params=getEditFormData();
	//3.提交异步请求,将数据写入到服务端
	var url="team/doSaveObject.do";
	$.post(url,params,function(result){
		if(result.state==1){
			$("#modal-dialog").modal("hide");
			doGetObjects();
		}else{alert(result.message);}
	});
}
/*获得表单数据*/
function getEditFormData(){
var params={
"name":$("#nameId").val(),
"projectId":$("#projectId").val(),
"valid":$('input[name="valid"]:checked').val(),
"note":$('#noteId').val()
};return params;
}
/*获得项目的id和名称*/
function doGetProjectIdAndNames(){
	var url="team/doFindPrjIdAndNames.do";
	$.getJSON(url,function(result){
		if(result.state==1){
			doInitProjectSelect(result.data);
		}else{
			alert(result.message);
		}
	})
}
/*初始化所属项目的select下拉框*/
function doInitProjectSelect(list){
	var select=$("#projectId");
	select.append(
	"<option>==请选择==</option>")
	var option=
	"<option value=[id]>[name]</option>"
	for(var i in list){
		select.append(
		option.replace("[id]",list[i].id)
		      .replace("[name]",list[i].name));
	}
}




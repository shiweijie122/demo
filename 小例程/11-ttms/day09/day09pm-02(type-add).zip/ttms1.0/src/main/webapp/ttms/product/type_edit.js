var zTree;
var setting = {
		data : {   
			simpleData : {
				enable : true,
				idKey : "id",  //节点数据中保存唯一标识的属性名称
				pIdKey : "parentId",  //节点数据中保存其父节点唯一标识的属性名称
				rootPId : null  //根节点id
			}
		}
}
$(document).ready(function(){
	$("#editTypeForm")
	.on("click",".load-product-type",doLoadZTreeNodes)
    $("#btn-save").click(doSaveOrUpdate)
    
    $("#typeLayer")
    .on("click",".btn-cancle",doHideZtree)
    .on("click",".btn-confirm",doSetSelectedNode);
});
function doSaveOrUpdate(){
	console.log("==doSaveOrUpdate==")
	//1.获得页面表单中的数据
	var params=getEditFormData();
	//2.发送异步请求提交数据
	var url="type/doSaveObject.do";
	$.post(url,params,function(result){
		if(result==1){
		var listUrl="type/listUI.do?t="+Math.random(1000);
		$("#container").load(listUrl);
		}else{
		alert(result.message);
		}
	})
}
function getEditFormData(){
	var params={
	  "name":$("#typeNameId").val(),
	  "parentId":$("#editTypeForm").data("parentId"),
	  "sort":$("#typeSortId").val(),
	  "note":$("#typeNoteId").val()
	};
	return params;
}
function doSetSelectedNode(){
	//1.获得选中的的节点对象
	var selectedNodes=//返回值是一个数组
	//getSelectedNodes是zTree中的一个函数
    zTree.getSelectedNodes();
	//2.获得具体的节点(node)对象
	var node=selectedNodes[0];
	//3.通过node节点数据更新页面内容
    $("#parentNameId").val(node.name);
    $("#editTypeForm").data("parentId",node.id);
    //4.隐藏zTree
    doHideZtree()
}
/**隐藏Ztree*/
function doHideZtree(){
 console.log("==doHideZtree==");
 $("#typeLayer").css("display","none");
}

/**显示Ztree以及树上的节点信息*/
function doLoadZTreeNodes(){
//1.显示Ztree(在type_edit.jsp页面上默认是隐藏的)
 $("#typeLayer").css("display","block");
//2.发送异步请求加载分类信息,更新Ztree节点内容
 var url="type/doFindZtreeObjects.do"
 $.getJSON(url,function(result){
	 console.log("result="+JSON.stringify(result))
	 if(result.state==1){
		 //访问zTree方法通过数据初始化节点信息
		 zTree=$.fn.zTree.init(
				 $("#typeTree"),
				 setting,
				 result.data);
	 }else{
		alert(result.message);
	 }
 });
 
 
}
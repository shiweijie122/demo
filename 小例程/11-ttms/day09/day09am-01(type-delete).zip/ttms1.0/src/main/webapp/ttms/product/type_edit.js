$(document).ready(function(){
	$("#editTypeForm")
	.on("click",".load-product-type",doLoadZTreeNodes)
    $("#typeLayer")
    .on("click",".btn-cancle,.btn-confirm",doHideZtree)
});
/**隐藏Ztree*/
function doHideZtree(){
 console.log("==doHideZtree==");
 $("#typeLayer").css("display","none");
}
/**显示Ztree以及树上的节点信息*/
function doLoadZTreeNodes(){
//1.显示Ztree(在type_edit.jsp页面上默认是隐藏的)
 $("#typeLayer").css("display","block");
//2.发送异步请求加载分类信息,更新Ztree节点内容
}
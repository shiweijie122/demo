package product.service;

import javax.security.auth.Destroyable;

import org.junit.After;
import org.junit.Before;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTeamService {

	private ClassPathXmlApplicationContext ctx;
	@Before
	public void init(){
		ctx=new ClassPathXmlApplicationContext(
		"spring-mvc.xml",
		"spring-pool.xml",
		"spring-mybatis.xml");
	}
	public void testFindObjects(){
		
	}
	@After
	public void destory(){
		ctx.close();
	}
}

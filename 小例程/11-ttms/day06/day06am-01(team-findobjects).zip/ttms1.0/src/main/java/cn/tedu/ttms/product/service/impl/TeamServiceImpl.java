package cn.tedu.ttms.product.service.impl;
import java.util.Map;

import org.springframework.stereotype.Service;

import cn.tedu.ttms.product.service.TeamService;
@Service
public class TeamServiceImpl implements TeamService {

	/**获得当前页的数据以及分页信息
	 * 1)List<Map<String,Object>
	 * 2)PageObject
	 * */
	@Override
	public Map<String,Object> 
	findObjects(Integer valid,
			    Integer projectId, 
			    Integer pageCurrent) {
		//1.判定参数数据的有效性
		//2.根据pageCurrent计算startIndex
		//3.执行查询操作获得当前页数据.
		//4.计算分页相关信息
		//5.封装数据(当前页记录,分页PageObject)
		return null;
	}

}

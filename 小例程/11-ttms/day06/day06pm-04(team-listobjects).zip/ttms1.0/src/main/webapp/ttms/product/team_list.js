$(document).ready(function(){
	doGetProjectIdAndNames();
	doGetObjects();
	
});

function doGetProjectIdAndNames(){
	var url="team/doFindPrjIdAndNames.do";
	$.getJSON(url,function(result){
		if(result.state==1){
		doInitProjectSelect(result.data);	
		}else{
		alert(result.message);
		}
	});
}
/*初始化项目select(id与name)列表*/
function doInitProjectSelect(list){
	var select=$("#searchPrjId");
	select.append('<option value="">选择项目名</option>')
	for(var i in list){
	 select.append(
	 "<option value="+list[i].id+">"+list[i].name+"<option>");
	}
}

function doGetObjects(){
 //1.通过异步请求($.post)获得服务端团信息
 var url="team/doFindObjects.do";
 var pageCurrent=
 $("#pageId").data("pageCurrent");
 if(!pageCurrent){pageCurrent=1;}
 var params={"pageCurrent":pageCurrent};
 
 $.post(url,params,function(result){
	if(result.state==1){
 //2.将团信息更新到页面的tbody位置
    //2.1记录信息
	  setTableBodyRows(result.data.list);
    //2.2分页信息
	  setPagination(result.data.pageObject);
	}else{
	  //显示业务异常信息
	  alert(result.message);
	}
 });
}
function setTableBodyRows(list){
	var tBody=$("#tbodyId");
	tBody.empty();
	var firstTd='<td><input type="radio" name="checkedItem" value="[id]"></td>';
	for(var i in list){//循环一次取一行
	 var tr=$("<tr></tr>");
	 tr.data("id",list[i].id);//绑定数据,便于修改时使用
	 tr.append(firstTd.replace("[id]",list[i].id));
	 tr.append("<td>"+list[i].name+"</td>");
	 tr.append("<td>"+list[i].projectName+"</td>");
	 tr.append("<td>"+(list[i].valid?"启用":"禁用")+"</td>")
	 tr.append('<td><button type="button" class="btn btn-default btn-update">修改</td>');
	 tBody.append(tr);
	}
}








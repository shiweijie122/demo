$(document).ready(function(){
	doGetObjects();
});
function doGetObjects(){
 //1.通过异步请求($.post)获得服务端团信息
 //2.将团信息更新到页面的tbody位置
 //2.1记录信息
 //2.2分页信息
}

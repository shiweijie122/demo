package cn.tedu.ttms.attachement.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import cn.tedu.ttms.attachement.entity.Attachement;


public interface AttachementService {
    /**实现文件上传*/
	public void uploadObject(String title,
			MultipartFile mFile);
	public List<Attachement> findObjects();
	public Attachement findObjectById(Integer id);
	
}

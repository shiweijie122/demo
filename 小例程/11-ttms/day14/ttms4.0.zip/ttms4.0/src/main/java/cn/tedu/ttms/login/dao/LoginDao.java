package cn.tedu.ttms.login.dao;

import cn.tedu.ttms.common.dao.BaseDao;
import cn.tedu.ttms.system.entity.User;

public interface LoginDao extends BaseDao<User> {

}

package cn.tedu.ttms.common.exception;

public class UpdateRuntimeException  extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 18794756827824687L;

	public UpdateRuntimeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UpdateRuntimeException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public UpdateRuntimeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UpdateRuntimeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UpdateRuntimeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}

package cn.tedu.ttms.product.dao;

import cn.tedu.ttms.common.dao.BaseDao;
import cn.tedu.ttms.product.entity.ProductType;
/**产品分类的持久层对象*/
public interface ProductTypeDao 
   extends BaseDao<ProductType>{
      
}

package cn.tedu.ttms.product.dao;

import java.util.List;
import java.util.Map;

import cn.tedu.ttms.common.dao.BaseDao;
import cn.tedu.ttms.product.entity.ProductType;
/**产品分类的持久层对象*/
public interface ProductTypeDao 
   extends BaseDao<ProductType>{
	List<Map<String,Object>>
	findObjects();
	
	
}

package cn.tedu.ttms.product.service;

import java.util.List;
import java.util.Map;

public interface ProductTypeService {
	/**查询分类的列表信息*/
	public List<Map<String,Object>> 
	findGridTreeObjects();
}







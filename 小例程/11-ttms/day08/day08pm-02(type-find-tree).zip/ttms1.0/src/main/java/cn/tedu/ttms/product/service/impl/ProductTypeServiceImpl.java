package cn.tedu.ttms.product.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.tedu.ttms.product.dao.ProductTypeDao;
import cn.tedu.ttms.product.service.ProductTypeService;
@Service
public class ProductTypeServiceImpl implements ProductTypeService {
	@Resource
	private ProductTypeDao productTypeDao;
	/**查询产品分类列表信息*/
	@Override
	public List<Map<String, Object>> 
	findGridTreeObjects() {
		return productTypeDao.findObjects();
	}

}

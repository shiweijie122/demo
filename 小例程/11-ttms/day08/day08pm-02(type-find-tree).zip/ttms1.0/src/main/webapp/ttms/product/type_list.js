var columns = [
{
field : 'selectItem',
radio : true
},
{
title : '分类id',
field : 'id',
visible : false,
align : 'center',
valign : 'middle',
width : '80px'
},
{
title : '分类名称',
field : 'name',
align : 'center',
valign : 'middle',
sortable : true,
width : '180px'
},
{
title : '上级分类',
field : 'parentName',
align : 'center',
valign : 'middle',
sortable : true,
width : '180px'
},
{
title : '排序号',
field : 'sort',
align : 'center',
valign : 'middle',
sortable : true,
width : '100px'
}];
$(document).ready(function(){
	doGetObjects();
});
function doGetObjects(){
 var tableId="typeTable";//对象type_list.jsp中的table id
 var url="type/doFindGridTreeObjects.do";
 var table=new TreeTable(tableId,url,columns);
 table.setIdField("id");//设置选中记录的返回id()
 table.setCodeField("id");//设置级联关系的id
 table.setParentCodeField("parentId");//设置级联关系中的parentId
 table.setExpandColumn(2);
 table.setExpandAll(false);//设置默认不展开
 table.init();//初始化对象树(底层会发起异步请求)
}


